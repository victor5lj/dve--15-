public class test {

    public static void main(String[] args) {
        book b=new book();
        b.menu();
    }

}
